var SimpleStorage = artifacts.require("./SimpleStorage.sol");
var Payroll = artifacts.require("./Payroll.sol");
var Ownable =  artifacts.require('zeppelin-solidity/contracts/ownership/Ownable.sol');
var SafeMath =  artifacts.require('zeppelin-solidity/contracts/ownership/SafeMath.sol');

module.exports = function(deployer) {
  deployer.deploy(SimpleStorage)
  deployer.deploy(Ownable)
  deployer.deploy(SafeMath)
  deployer.link(Ownable, Payroll);
  deployer.link(SafeMath, Payroll);
  deployer.deploy(Payroll)
};
