import React, { Component } from 'react'
import {Form,InputNumber,Button } from 'antd';
import Common from './Common';
const FormItem = Form.Item;

class Fund extends Component{

    constructor(props){
        super(props);
        this.state={};
    }


    componentDidMount(){
        const {payroll, web3, account}=this.props;
        payroll.getInfo.call({from: account}).then(result=>{
            this.setState({
                balance:web3.fromWei(result[0].toNumber()),
                runway:result[1].toNumber(),
                employeeCount:result[2].toNumber()
            });
        });
    }

    handleSubmit =(ev) =>{
        ev.preventDefault();
        const {payroll, account, web3} = this.props;
        payroll.addFund({
            from: account,
            value: web3.toWei(this.state.fund)
        });
    }
    render(){
        const {payroll, account, web3} = this.props;
        return(
            <div>
                <Common account={account} payroll={payroll} web3={web3}/>
                <Form layout='inline' onSubmit={this.handleSubmit}>
                    <FormItem>
                        <InputNumber
                        min={1}
                        onchange={fund => {this.setState({fund})}}
                        />
                    </FormItem>
                    <FormItem>
                        <Button
                            type='primary'
                            htmlType="submit"
                            disabled={!this.state.fund}
                        >
                        addfund
                        </Button>
                    </FormItem>    
                </Form>
            </div>    
        )   
    }
}