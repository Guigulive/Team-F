import React, { Component } from 'react'
import {Card, Col,Row,Layout,Alert,Message,Button} from 'antd';
import Common from './Common';
class Employee extends Component{

    constructor(props){
        super(props);
        this.state={};
    }

    componentDidMount(){
        this.checkEmployee();
    }

    checkEmployee=()=>{
        const {payroll, account, web3} =this.props;
        payroll.employeeList.call(account,{
            from:account,
            gas:1000000
        }).then((result)=>{
            console.log(result);
            this.setState({ 
                salary:web3.fromWei(result[1].toNumber()),
                lastPaidDate:new Date(result[2].toNumber()*1000)
            });
        });

        web3.eth.getBalance(account,(err,result)=>{
            this.setState({
                balance: web3.fromWei(result[1].toNumber())
            });
        });
    }



    getPaid=()=>{
        const {payroll, employee, web3} =this.props;
        payroll.getPaid({
            from:employee,
            gas:1000000
        }).then((result)=>{
            Message.info("You have been paid.");

        });

    }


    renderContent(){
        const {salary, lastPaidDate,balance} = this.state;
        // if(!salary || salary==='0') {
        //     return <Alert message="you are not an employee" type="error" shoeIcon/>;
        // };

        return(
            <div>
                <h2>Pernonal Informaiotn</h2>
                <Row gutter={16}>
                    <Col span={8}>
                        <Card title="Salary"> {salary}</Card> 
                    </Col>
                    <Col span={8}>
                        <Card title="LastPaidDayte"> {lastPaidDate}</Card> 
                    </Col>
                    <Col span={8}>
                        <Card title="Balance in Contract"> {balance}</Card> 
                    </Col>

                </Row>
                <Button type='primary' icon='bank' onClick={this.getPaid}>Get Paid</Button>
            </div>
        );
    };

    render(){
        
        const {payroll, account, web3} = this.props;

        return (

            <Layout style={{padding:'24px 0', background: '#fff '}}>
                <Common account={account} payroll={payroll} web3={web3}/>
                    {this.renderContent()}
                    
            </Layout>

        );

    }


}

export default Employee;