import React, { Component } from 'react'
import {Layout,Menu,Alert} from 'antd';
 import Fund from  './Fund';
// import EmployeeList from './EmployeeList';
const {Content,Sider} = Layout;
class Employer extends Component{

    constructor(props){
        super(props);
        this.state={};
    }

    componentDidMount(){
        const {account, payroll} = this.props;
        payroll.owner.call({from: account}).then(
            (result) => {  this.setState({owner:result})}
        )    
    } 

    onSelectTab = ({key}) =>{
        this.setState( {
            mode:key
        })

    }


    addFund=()=>{
        const {payroll, employer, web3}=this.props;

        payroll.addFund({
            from:employer,
            value:web3.toWei(this.fundInput.value)
        });


    }



    addEmployee=()=>{

        const {payroll, employer}=this.props;
        payroll.addEmployee(this.employeeInput.value, parseInt(this.salaryInput.value,10),{
            from:employer,
            gas:1000000
        }).then(result=>{
            alert("success");
        });

    }

    updateEmployee=()=>{

        const {payroll, employer}=this.props;
        payroll.updateEmployee(this.employeeInput.value,parseInt(this.salaryInput.value),{
            from:employer,
            gas:1000000
        }).then(result=>{
            alert('success');
        });

    }


    removeEmployee=()=>{

        const {payroll, employer}=this.props;
        payroll.removeEmployee(this.removeEmployeeInput.value,{
            from:employer,
            gas:1000000
        }).then(result=>{
            alert('success');
        });

    }


    renderContent=()=>{
        const{account,payroll,web3} = this.props;
        const{mode,owner} = this.state;
        // if (owner!==account){
        //     return <Alert message="You are not the owner!" type="error" showicon/>;
        // }   
        switch(mode){
            case 'fund':  
                {alert('fund');
                return<Fund account={account} payroll={payroll} web3={web3}/> ;   
                
                break;}
                
            case 'EmployeeList':   
               { alert('employeelist');
                break;}
              //  return<EmployeeList account={account} payroll={payroll} web3={web3}/> ;            
            
        }


    }


    render(){
        return ( 
             <Layout style={{padding:'24px 0', background: '#fff '}}>
                <Sider width={200} stype={{background: '#fff'}}>
                    <Menu
                        mode="inline"
                        defaultSelectedKeys={['fund']}
                        style={{height:'100%'}}
                        onSelect={this.onSelectTab}
                    > 
                        <Menu.Item key='fund'>Contract Information</Menu.Item>    
                        <Menu.Item key='EmployeeList'> Employee Informaiotn </Menu.Item>
                    </Menu>
                </Sider>
                <Content style={{ padding:'24px 0',minHeight:280}}>
                        {this.renderContent()}
                                    {/* <div>
                <h2>雇主</h2>
                <form className="pure-form pure-form-stacked">
                    <fieldset>
                        <legend>注资</legend>
                        <label>金额</label>
                        <input 
                            type="text" placeholder="fund" ref={(input)=>{this.fundInput=input;}} />
                        <button type="submit" className="pure-button" onClick={this.addFund}>添加资金</button>
                    </fieldset>
                </form>

                <form className="pure-form pure-form-stacked">
                    <fieldset>
                        <legend>添加/更新 员工</legend>
                        <label>员工Id</label>
                        <input type="text" placeholder="employee" ref={(input)=>{this.employeeInput=input;}} />
                        <label>salary</label>
                        <input type="text" placeholder="salary" ref={(input)=>{this.salaryInput=input;}} />

                        <button type="submit" className="pure-button" onClick={this.addEmployee}>添加</button>
                        <button type="submit" className="pure-button" onClick={this.updateEmployee}>更新</button>

                    </fieldset>
                </form>

                <form className="pure-form pure-form-stacked">
                    <fieldset>
                        <legend>移除员工</legend>
                        <label>员工Id</label>
                        <input 
                            type="text" placeholder="employee" ref={(input)=>{this.removeEmployeeInput=input;}} />
                        <button type="submit" className="pure-button" onClick={this.removeEmployee}>移除</button>
                    </fieldset>
                </form>
            </div>*/}
                </Content>
            </Layout>    

        );

    }
}

export default Employer;